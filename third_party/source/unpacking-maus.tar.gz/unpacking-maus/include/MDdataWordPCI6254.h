/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordPCI6254.h,v $
 * Revision 1.1  2009/04/21 12:44:42  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich, February 2009                      *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDDATWORDPCI6254_H
#define __MDDATWORDPCI6254_H

#include "MDdataWord.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>


using namespace std;

class MDdataWordPCI6254 : public MDdataWord {

 public:
  MDdataWordPCI6254( void *d = 0 );
  ~MDdataWordPCI6254(){}

  virtual void Dump(int atTheTime=1);  
};


ostream &operator<<(ostream &s,MDdataWordPCI6254 &dw);
istream &operator>>(istream &s,MDdataWordPCI6254 &dw);

#endif
