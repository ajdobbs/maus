/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordV1731.h,v $
 * Revision 1.1  2009/04/21 12:44:50  daq
 * Initial revision
 *
 *
 *                                                                         *
 * Originally created by J.S. Graulich, December 2008                      *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDDATWORDV1731_H
#define __MDDATWORDV1731_H

#include "MDdataWord.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

typedef enum DWV1731Header {
  DWV1731_Header_Sync                = 0xA0000000,
  DWV1731_Header_Sync_Word           = 0,
  DWV1731_Header_Sync_Mask           = 0xF0000000,
  DWV1731_Header_WordCount_Mask      = 0x0FFFFFFF,
  DWV1731_Header_WordCount_Word      = 0,
  DWV1731_Header_WordCount_Shift     = 0,
  DWV1731_Header_Geo_Mask            = 0xF8000000,
  DWV1731_Header_Geo_Word            = 1,
  DWV1731_Header_Geo_Shift           = 27,
  DWV1731_Header_ZLE_Mask            = 0x01000000,
  DWV1731_Header_ZLE_Word            = 1,
  DWV1731_Header_ZLE_Shift           = 24,
  DWV1731_Header_Pattern_Mask        = 0x00FFFF00,
  DWV1731_Header_Pattern_Word        = 1,
  DWV1731_Header_Pattern_Shift       = 8,
  DWV1731_Header_ChannelMask_Mask    = 0x000000FF,
  DWV1731_Header_ChannelMask_Word    = 1,
  DWV1731_Header_ChannelMask_Shift   = 0,
  DWV1731_Header_EventCounter_Mask   = 0x00FFFFFF,
  DWV1731_Header_EventCounter_Word   = 2,
  DWV1731_Header_EventCounter_Shift  = 0,
  DWV1731_Header_TriggerTimeTag_Mask = 0xFFFFFFFF,
  DWV1731_Header_TriggerTimeTag_Word = 3,
  DWV1731_Header_TriggerTimeTag_Shift = 0 

} DWV1731Header;

typedef enum DWV1731Sample {
  DWV1731_Sample_Shift      = 8,
  DWV1731_Sample_DataMask   =  0x000000FF,
  DWV1731_Sample_CheckMask  =  0x00000000

} DWV1731Sample;


class MDdataWordV1731 : public MDdataWord {

 public:
  
  MDdataWordV1731( void *d = 0 );
  ~MDdataWordV1731(){}

  int16_t GetSample(unsigned int is) {
    return (Get32bWordPtr()[0] >> is*DWV1731_Sample_Shift) & DWV1731_Sample_DataMask;
  }

  bool   IsValid(){
    if (_data)
      return 1; // TODO make this a real test valid for both data and header
    else
      return 0;
 }

  virtual void Dump( int atTheTime = 1 );

 private:
};

ostream &operator<<(ostream &s,MDdataWordV1731 &dw);
istream &operator>>(istream &s,MDdataWordV1731 &dw);


#endif
