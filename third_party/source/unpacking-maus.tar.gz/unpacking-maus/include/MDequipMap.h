/***************************************************************************
 *                                                                         *
 * $Log: MDequipMap.h,v $
 * Revision 1.3  2009/04/21 12:45:44  daq
 * Introduce PCI6254 and V1731
 *
 * Revision 1.2  2008/04/29 07:41:49  daq
 * Declare Dump() and GetType()
 *
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 10:03:51  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/
#ifndef __MDEQUIPMAP_H
#define __MDEQUIPMAP_H

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <utility>

class MDfragment;
#include "MDdataContainer.h"

#define ADD_EQUIP_IN_MAP(t,s)  _equipMap[(t)] = new MDequipDesc((#s),new MDfragment##s)

using namespace std;

class MDequipDesc {
 private:
  string              name;
  MDfragment*         dcPtr;

  public:
  MDequipDesc(string s, MDfragment* ptr):name(s),dcPtr(ptr){
    //        cout << " Create a new MDequipDesc" << endl;
  }
  ~MDequipDesc(){}
  string GetName(){return name;}
  MDdataContainer* GetDataContainerPtr();
  MDfragment* GetFragmentPtr(){return dcPtr;}

};

typedef map<uint32_t, MDequipDesc*> equipMap_t ;

class MDequipMap {
 private:
  void SetEquipmentTypes();
  equipMap_t::iterator find( unsigned int type ) {
    return _equipMap.find(type);
  }

 public:
  //  static equipMap_t _equipMap;
  static equipMap_t _equipMap;
  static int _count;

  MDequipMap();
  ~MDequipMap(); 
  static void Dump();

  static equipMap_t::iterator begin() {
    return _equipMap.begin();
  }

  static equipMap_t::iterator end() {
    return _equipMap.end();
  }

  static unsigned int size() {
    return _equipMap.size();
  }


  static bool IsDefined(unsigned int aType ){
    if (_count) {
      equipMap_t::iterator it=_equipMap.find(aType);
      if ( it->first == aType ) return true;
    }
    return false;
  }

  static  unsigned int GetType( string name );

  static bool IsDefined(string name){
    return !!GetType(name);
  }

  static string GetName( unsigned int type ) {
    if (IsDefined(type)) {return _equipMap[type]->GetName();}
    return string("Unknown");
  }

  static MDdataContainer* GetDataContainerPtr(int type) {
    if (IsDefined(type)) {return _equipMap[type]->GetDataContainerPtr();}
    return NULL;
  }

  static MDfragment* GetFragmentPtr(int type) {
    if (IsDefined(type)) {return _equipMap[type]->GetFragmentPtr();}
    return NULL;
  }

};


#endif
