/***************************************************************************
 *                                                                         *
 * $Log: MDevent.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.5  2008/01/30 14:57:58  daq
 * Change types of nSubEvents and nFragments to unsigned int
 *
 * Revision 1.4  2008/01/29 16:38:35  daq
 * Introduce private vectors preserving the references of subEvents and fragments
 *
 * Revision 1.3  2007/07/20 17:23:06  daq
 * Introduce default argument for Dump()
 *
 * Revision 1.2  2007/06/28 16:29:56  daq
 * First Working version
 *
 * Revision 1.1  2007/06/27 12:01:07  daq
 * Initial revision
 *
                                                                           *
 * Originally created by J.S. Graulich june 2007                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDEVENT_H
#define __MDEVENT_H

#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iostream>
#include "event.h"
#include "MDdataContainer.h"
#include "MDeventFragment.h"

using namespace std;

class MDevent : public MDdataContainer  {
  ///////  data   ////////
 private:
  unsigned int            nFragments;
  vector<void *> fragment;

  unsigned int            nSubEvents;
  vector<void *> subEvent;

 public:
  ///////  Member functions   ////////
  MDevent(void *d=0);

  virtual ~MDevent(){}
  virtual void SetDataPtr( void *d );

  void Init();
  bool InitFragments();
  bool InitSubEvents();

  eventHeaderStruct* HeaderPtr(){ return (eventHeaderStruct *) _data; }

  uint32_t EventSize(){ return  HeaderPtr()->eventSize ; }
  uint32_t* EventSizePtr(){ return &(HeaderPtr()->eventSize); }

  uint32_t Magic(){ return HeaderPtr()->eventMagic ; }
  uint32_t* MagicPtr(){ return &(HeaderPtr()->eventMagic); }

  uint32_t  HeadSize(){ return HeaderPtr()->eventHeadSize ; }
  uint32_t* HeadSizePtr(){ return &(HeaderPtr()->eventHeadSize) ; }

  uint32_t  Version(){ return HeaderPtr()->eventVersion ; }
  uint32_t* VersionPtr(){ return &(HeaderPtr()->eventVersion) ; }

  uint32_t  EventType(){ return HeaderPtr()->eventType ; }
  uint32_t* EventTypePtr(){ return &(HeaderPtr()->eventType) ; }

  uint32_t  RunNb(){ return HeaderPtr()->eventRunNb ; }
  uint32_t* RunNbPtr(){ return &(HeaderPtr()->eventRunNb) ; }

  uint32_t* EventIdPtr(){ return HeaderPtr()->eventId; }

  uint32_t* TriggerPatternPtr(){ return HeaderPtr()->eventTriggerPattern; }

  uint32_t* DetectorPatternPtr(){ return HeaderPtr()->eventDetectorPattern; }

  uint32_t* EventTypeAttributePtr(){ return HeaderPtr()->eventTypeAttribute; }

  uint32_t  LdcId(){ return HeaderPtr()->eventLdcId; }
  uint32_t* LdcIdPtr(){ return &(HeaderPtr()->eventLdcId); }

  uint32_t  GdcId(){ return HeaderPtr()->eventGdcId; }
  uint32_t* GdcIdPtr(){ return &(HeaderPtr()->eventGdcId); }

  uint32_t* TimeStampPtr(){ return &(HeaderPtr()->eventTimestamp); }

  unsigned char* PayLoadPtr(){ return (_data + *HeadSizePtr()); }

  virtual void Dump(int atTheTime=1);

  uint32_t Nequipment();
  uint32_t NsubEvent();

  uint32_t  PayLoadSize();

  void* GetFragmentPtr(int ifr){ return fragment[ifr]; }
  uint32_t GetNFragments(){ return nFragments; }

  void* GetSubEventPtr(int ifr){ return subEvent[ifr]; }
  uint32_t GetNSubEvents(){ return nSubEvents; }

  bool IsSuperEvent(){
    return TEST_SYSTEM_ATTRIBUTE( HeaderPtr()->eventTypeAttribute,
				  ATTR_SUPER_EVENT );
  }
};

/////////////////////////////////////////////////////////////////////////////

class MDeventType : public MDdataContainer {
 public:
  MDeventType(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = sizeof(eventTypeType);
    }
  }
  MDeventType(MDeventType& et) {
    _data  = et.GetDataPtr();
    _size  = et.GetSize();
    _valid = et.IsValid();
  }
  virtual ~MDeventType(){}
};
ostream &operator<<(ostream &s,MDeventType &e);

/////////////////////////////////////////////////////////////////////////////

class MDeventId : public MDdataContainer {
 public:
  MDeventId(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = EVENT_ID_BYTES;
    }
  }
  virtual ~MDeventId(){}
};
ostream &operator<<(ostream &s,MDeventId &e);

/////////////////////////////////////////////////////////////////////////////

class MDeventTypeAttribute : public MDdataContainer {
 public:
  MDeventTypeAttribute(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = ALL_ATTRIBUTE_BYTES;
    }
  }
  virtual ~MDeventTypeAttribute(){}
};
ostream &operator<<(ostream &s,MDeventTypeAttribute &e);

/////////////////////////////////////////////////////////////////////////////

class MDtriggerPattern : public MDdataContainer {
 public:
  MDtriggerPattern(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = EVENT_TRIGGER_PATTERN_BYTES;
    }
  }
  virtual ~MDtriggerPattern(){}
};
ostream &operator<<(ostream &s,MDtriggerPattern &e);

/////////////////////////////////////////////////////////////////////////////

class MDdetectorPattern : public MDdataContainer {
 public:
  MDdetectorPattern(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = EVENT_DETECTOR_PATTERN_BYTES;
    }
  }
  virtual ~MDdetectorPattern(){}
};
ostream &operator<<(ostream &s,MDdetectorPattern &e);


#endif
