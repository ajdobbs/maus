/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDFRAGMENTV1290_H
#define __MDFRAGMENTV1290_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDdataWordV1290.h"
#include "MDpartEventV1290.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;


class MDfragmentV1290 : public MDfragment {

 public:

  MDfragmentV1290( void *d = 0 );
  virtual ~MDfragmentV1290(){}
  virtual void SetDataPtr( void *d, uint32_t aSize );
  virtual void Init();

  virtual void SetTest(DataTestCallback funk) {
    if (_partEventPtr) _partEventPtr->SetTest( funk );
  }

 private:
};

#endif
