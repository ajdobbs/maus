/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDFRAGMENTV1731_H
#define __MDFRAGMENTV1731_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDdataWordV1731.h"
#include "MDpartEventV1731.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

class MDfragmentV1731 : public MDfragment {

 public:

  MDfragmentV1731( void *d = 0 );
  virtual ~MDfragmentV1731(){}
  virtual void SetDataPtr( void *d, uint32_t aSize );
  virtual void Init();

  virtual void SetTest(DataTestCallback funk) {
    if (_partEventPtr) _partEventPtr->SetTest( funk );
  }

 private:
};

#endif
