/***************************************************************************
 *                                                                         *
 * $Log: MDpartEventV1724.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.2  2008/01/31 00:33:53  daq
 * Introduce new private data: _nChannels, _length and _sequence.
 * Introduce new member functions needed by GetSampleData()
 *
 * Revision 1.1  2008/01/25 10:14:02  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich, December 2007                      *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDPARTEVENTV1724_H
#define __MDPARTEVENTV1724_H

#include "MDdataContainer.h"
#include "MDdataWordV1724.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
 
#define V1724_HEADER_WORDS 4
#define V1724_WORD_SIZE    4
#define V1724_NCHANNELS    8


class MDpartEventV1724 : public MDdataContainer {
 private:
  unsigned int  _nChannels;
  unsigned int  _length[ V1724_NCHANNELS ];
  unsigned int* _sequence[ V1724_NCHANNELS ];


 public:
  
  MDpartEventV1724( void *d = 0 );
  virtual ~MDpartEventV1724(){}
  virtual void SetDataPtr( void *d );

  void Init();

  unsigned int GetNChannels(){ return _nChannels; }
  unsigned int GetLength(int ch){ return _length[ch]; }
  unsigned int GetNSamples(int ch){ return 2*_length[ch]; } // 2 sample data per word
  unsigned int* GetSequence(int ch){ return _sequence[ch]; }

  unsigned int GetWordCount();

  unsigned int GetGeo();
  int          GetZLE();
  unsigned int GetPattern();
  unsigned int GetChannelMask();

  unsigned int GetEventCounter();
  unsigned int GetEventCount(){ return GetEventCounter()-1; }

  unsigned int GetTriggerTimeTag();

  int16_t GetSampleData( unsigned short aChannel, unsigned long aSample );


  virtual void Dump( int atTheTime = 1 );

};

ostream &operator<<(ostream &s,MDpartEventV1724 &dw);
istream &operator>>(istream &s,MDpartEventV1724 &dw);


#endif
