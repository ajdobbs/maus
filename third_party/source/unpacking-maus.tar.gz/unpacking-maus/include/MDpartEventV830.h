/***************************************************************************
 *                                                                         *
 * $Log: MDpartEventV830.h,v $
 * Revision 1.2  2009/04/21 12:47:15  daq
 * Debug.
 *
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 10:14:02  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich, December 2007                      *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDPARTEVENTV830_H
#define __MDPARTEVENTV830_H

#include "MDdataContainer.h"
#include "MDdataWordV830.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;
 

class MDpartEventV830 : public MDdataContainer {

 public:
  
  MDpartEventV830( void *d = 0 );
  virtual ~MDpartEventV830(){}
  virtual void SetDataPtr( void *d );
  unsigned int GetWordCount(){return _wordCount;}
  unsigned int GetGeo(){return _geo;}
  unsigned int GetChannel(unsigned int iw);
  unsigned int GetMeasurement(unsigned int iw);

  void Init();

  virtual void Dump( int atTheTime = 1 );
 private:
  unsigned int   _geo;
  unsigned int   _wordCount;
  unsigned int   _ts;
  unsigned int   _triggerCount;  
};

#endif
