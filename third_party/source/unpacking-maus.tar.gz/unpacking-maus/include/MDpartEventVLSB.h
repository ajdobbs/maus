/***************************************************************************
 *                                                                         *
 * Originally created by J.S. Graulich and Y. Karatzhov  June 2011         *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDPARTEVENTVLSB_H
#define __MDPARTEVENTVLSB_H

#include <stdlib.h>
#include <vector>
#include <stdio.h>
#include <iostream>
#include <fstream>

#include "MDdataContainer.h"
#include "MDdataWordVLSB.h"
#include "MDexception.h"

using namespace std;

#define VLSB_BANK_NCHANNELS    128

class MDpartEventVLSB : public MDdataContainer {
 public:
  MDpartEventVLSB( void *d = 0 );
  virtual ~MDpartEventVLSB(){}
  virtual void SetDataPtr( void *d );

  /// Loop of the data to set the correct _size and check data format
  void Init(); 

  unsigned int GetNHits(){return _nHits;}
  unsigned int GetWordCount(){return _nHits;}
  int GetEventNum(){return _eventNumber;}
  unsigned int GetChannel(unsigned int ih);
  unsigned int GetAdc(unsigned int ih);
  unsigned int GetTdc(unsigned int ih);
  bool GetDiscriBit(unsigned int ih);
  virtual void Dump(int atTheTime=1);

 private:
  int _eventNumber;
  unsigned int _nHits; // one word per hits, life is easy

};

#endif
