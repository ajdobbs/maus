#include "MDdataWordDBB.h"

MDdataWordDBB::MDdataWordDBB(void *d):MDdataWord(d){}

bool   MDdataWordDBB::IsValid(){
  if (!_data) return false;
  return true;
}
unsigned long32 MDdataWordDBB::GetDataType()
{
  if (IsValid()) return ( (*(unsigned long32*)(_data) & DataTypeMask ) >> DataTypeShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetTriggerCount()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & TriggerCountMask ) >> TriggerCountShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetHitCount()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & HitCountMask ) >> HitCountShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetGeo()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & BoardIdMask ) >> BoardIdShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetSpillNumber()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & SpillNumberMask ) >> SpillNumberShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetChannelId()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & ChannelIdMask ) >> ChannelIdShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetHitTime()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & HitTimeMask ) >> HitTimeShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetStatus()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & StatusMask ) >> StatusShift );
  return 0;
}

unsigned long32 MDdataWordDBB::GetSpillWidth()
{
  if (IsValid())  return ( (*(unsigned long32*)(_data) & SpillWidthMask ) >> SpillWidthShift );
  return 0;
}







