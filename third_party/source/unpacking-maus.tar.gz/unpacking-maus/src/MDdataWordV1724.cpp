/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordV1724.cpp,v $
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.2  2008/01/25 10:02:51  daq
 * Full review.
 *
 * Revision 1.1  2007/12/14 09:42:38  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by v. Verguilov, Nov 2007                          *
 *                                                                         *
 ***************************************************************************/

#include "MDdataWordV1724.h"

MDdataWordV1724::MDdataWordV1724(void *d):MDdataWord(d) {
}

void MDdataWordV1724::Dump(int atTheTime){
  cout << *this;
  return;
} 

////////////////////////////////////////////////////////////////////////

ostream &operator<<(ostream &s,MDdataWordV1724 &dw){
//long32 dt = dw.GetDataType();
  if (  !dw.IsValid() ) {
    s << " INVALID ( " << showbase << hex << dw.Get32bWordPtr()[0] << " ) " ;
  }
  s << " CAEN V1724 Data: " << dec 
    << dw.GetSample(0) << " ; " <<  dw.GetSample(1) << endl; 
  s << dec << noshowbase;
  return s;
}

