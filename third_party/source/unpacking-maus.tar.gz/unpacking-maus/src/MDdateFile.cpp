/***************************************************************************
 *                                                                         *
 * $Log: MDdateFile.cpp,v $
 * Revision 1.2  2008/04/29 07:36:54  daq
 * change type of _eventBuffer form unsigned char* to char*.
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 14:14:46  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/

#include "MDdateFile.h"

MDdateFile::MDdateFile(string fn, string fp):_curPos(0),_eventBuffer(NULL),_filePath(fp),
					     _fileName(fn),_eventSize(0),_fileSize(0),_nBytesRead(0){
  _status =  DATE_FILE_NOT_OPEN  ;
}

dateFileStatus_t MDdateFile::OpenFile() {

  string fullName = _filePath + "/" + _fileName;

  _ifs.open( fullName.c_str() );
  if ( _ifs.fail() ) {
    cerr << "Can not open file " << fullName.c_str() << endl;
    return DATE_FILE_ERROR_IO;
  }
  long end;
  _curPos = _ifs.tellg();
  _ifs.seekg (0, ios::end);
  end = _ifs.tellg();
  _fileSize = end - _curPos;
  //  cout << " File size " << _fileSize << endl;
  if ( _fileSize%4 != 0 ) {
    cerr << " File size is not a multiple of 4. Fatal !" << endl;
    return DATE_FILE_ERROR_FORMAT;
  }
  _ifs.seekg (0, ios::beg); // go back to the begining ( = _curPos )
  _status =  DATE_FILE_OK ;
  return _status;
}

unsigned char* MDdateFile::GetNextEvent() {
  _curPos = _ifs.tellg();
  if ( IsOk() && _nBytesRead < _fileSize ) {
    free(_eventBuffer);

    if  ( !_ifs.read( ( char* ) &_eventSize, sizeof( _eventSize ) ) ) { // read event size
      cerr <<  "Unexpected End of File while trying to read event Size" << endl;
      _status = DATE_FILE_ERROR_EOF;
      return NULL;
    } else { // read OK, go back to previous position
      _ifs.seekg (_curPos , ios::beg);
      _nBytesRead += sizeof( _eventSize );
      //      cout << " Event size " << _eventSize << endl;
      if ( _eventSize ) { // allocate memory for the event
	_eventBuffer = (unsigned char*)malloc(_eventSize);
	if ( _eventBuffer == NULL )  {
	  cerr <<  "Memory allocation failed in MDdateFile::GetNextEvent()" << endl;
	  return NULL;
	}
	if  ( !_ifs.read( (char*)_eventBuffer, _eventSize ) ) { // read full DAQ event
	  cerr <<  "Unexpected End of File while trying to read event" << endl;
	  _status = DATE_FILE_ERROR_EOF;
	  return NULL;
	} else { // read OK
	  _nBytesRead += _eventSize;
	  return _eventBuffer;
	}
      } else {
	return NULL;
      }
    }
  } else {
    return NULL;
  }
}
