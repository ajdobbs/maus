/***************************************************************************
 *                                                                         *
 * $Log: MDeventFragment.cpp,v $
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.7  2008/04/10 11:13:36  daq
 * Improve recovery procedure.
 * Improve dump output format
 *
 * Revision 1.6  2008/04/08 14:04:01  daq
 * Introduce vector of particle events.
 * Introduce new member function InitPartEventVector().
 *
 * Revision 1.5  2008/01/25 10:10:47  daq
 * Introduce the new MDequipMap scheme
 *
 *
 * Originally created by J.S. Graulich june 2007                           *
 *                                                                         *
 ***************************************************************************/
#include "MDeventFragment.h"

MDeventFragment::MDeventFragment(void *d):MDdataContainer(d){
  Init();
};

void MDeventFragment::Init() {
  _valid = false;
  if (_data) {
    _size = *EquipmentSizePtr();
    _valid = true;
  }
} 

void MDeventFragment::SetDataPtr( void *d ) { 
  MDdataContainer::SetDataPtr(d);
  Init();
}


void MDeventFragment::Dump(int atTheTime){
  MDfragment* frag;
  
  int i;
  cout << "- - - - - - - - - - - - - MDeventFragment Dump - - - - - - - - - - - - - - - - " << dec << endl;
  cout << "Size:" << *EquipmentSizePtr() 
       << " (header:" << sizeof(equipmentHeaderStruct) << ")"
       << " Type:" << *EquipmentTypePtr()
       << " EquipId:" << *EquipmentIdPtr()
       << " BasicSize:" << *BasicElementSizePtr() <<  endl;
  cout << "Attributes: (" ;
  for ( i = 0; i != ALL_ATTRIBUTE_WORDS; i++ ) {
    cout << noshowbase << setfill('0') << setw(8) << hex << EquipmentTypeAttributePtr()[i];
    if ( i != ALL_ATTRIBUTE_WORDS-1 ) cout << ".";
  }
  cout << ")" << dec << endl ; 

  frag = MDequipMap::GetFragmentPtr(*EquipmentTypePtr()); 
  // frag is assigned dynamically to the corret MDfragmentEquip 
  //    cout << "Equipment " << MDequipMap::GetName(*EquipmentTypePtr()) ;
  //    cout << " found in the equipment map with type " << frag->GetEquipmentType() << endl ;
  if(frag) { // The equipment has been found in the map
    frag->SetDataPtr(EquipmentDataPtr(), EquipmentDataSize());
    frag->InitPartEventVector();
    frag->Dump();
  } else {
    cout << "Equipment not found in the map " << endl ;
  }

};
