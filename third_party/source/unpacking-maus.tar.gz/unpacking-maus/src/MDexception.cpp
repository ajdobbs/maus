#include "MDexception.h"

MDexception::MDexception(const std::string & aErrorDescription, MD_SEVERITY aSeverity):
  mErrorDescription(aErrorDescription),mSeverity(aSeverity)
{
}

