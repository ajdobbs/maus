/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich May 2011                            *
 *                                                                         *
 ***************************************************************************/

#include "MDfragmentV1290.h"

MDfragmentV1290::MDfragmentV1290(void *d):MDfragment(d){ 
  // A fragment should be created only once inside the map
  _partEventPtr = new MDpartEventV1290(0);
  Init();
}

void MDfragmentV1290::SetDataPtr( void *d, uint32_t aSize ) {
  MDfragment::SetDataPtr(d, aSize);
}

void MDfragmentV1290::Init(){
  uint32_t * ptr = Get32bWordPtr(0);
  MDdataWordV1290 dw(ptr);
  UnValidate();
  _madeOfParticles = true;
 
  //  cout << "Execute MDfragmentV1290::Init() " << endl;
  if ( dw.IsValid() ) {
    if (dw.GetDataType() != DWV1290_GlobalHeader ){ // The data doesn't start with a header
      cout << "WARNING in MDfragmentV1290::Init: 1st word is not a header" << endl;
      throw MDexception("ERROR in MDframentV1290::Init() : 1st word is not a header ***", MDexception::WARNING) ; 
    } else {
      _boardID = dw.GetGeo();  // this should be the same as the one from equipment header
    }
    Validate();
  }
}

////////////////////////////////////////////////////////////////////////


