/***************************************************************************
 *                                                                         *
 * Originally created by J.S. Graulich May 2011                            *
 *                                                                         *
 ***************************************************************************/

#include "MDfragmentVLSB.h"

MDfragmentVLSB::MDfragmentVLSB(void *d):MDfragment(d){ 
  //  cout << " Creating a MDfragmentVLSB ..." << endl; 
  _partEventPtr = new MDpartEventVLSB(0);
  Init();
}

void MDfragmentVLSB::SetDataPtr( void *d, uint32_t aSize ) {
  MDfragment::SetDataPtr(d,aSize);
 // The dynamically correct Init() is called by MDfragment::SetDataPtr(d,aSize)
}

void MDfragmentVLSB::Init(){
  //  cout << "MDfragmentVLSB::Init()" << endl;
  uint32_t * ptr = Get32bWordPtr(0);
  MDdataWordVLSB dw(ptr);
  UnValidate();
  _madeOfParticles = true;
  
  // Checking the first word to start with
  if ( dw.IsValid() ) { 
    Validate(); 
    // There is nothing else we can do here.
  }
}

unsigned int MDfragmentVLSB::GetEventNum(unsigned int ih){
  if (ih<GetPayLoadWordCount()) {
    MDdataWordVLSB dw(Get32bWordPtr(ih));
    return dw.GetEventNum();
  } else {
    return 0;
  }
}

bool MDfragmentVLSB::GetDiscriBit(unsigned int ih){
  if (ih<GetPayLoadWordCount()) {
    MDdataWordVLSB dw(Get32bWordPtr(ih));
    return dw.GetDiscriBit();
  } else {
    return 0;
  }
}

unsigned int MDfragmentVLSB::GetChannel(unsigned int ih){
  if (ih<GetPayLoadWordCount()) {
    MDdataWordVLSB dw(Get32bWordPtr(ih));
    return dw.GetChannel();
  } else {
    return 0;
  }
}

unsigned int MDfragmentVLSB::GetAdc(unsigned int ih){
  if (ih<GetPayLoadWordCount()) {
    MDdataWordVLSB dw(Get32bWordPtr(ih));
    return dw.GetAdc();
  } else {
    return 0;
  }
}

unsigned int MDfragmentVLSB::GetTdc(unsigned int ih){
  if (ih<GetPayLoadWordCount()) {
    MDdataWordVLSB dw(Get32bWordPtr(ih));
    return dw.GetTdc();
  } else {
    return 0;
  }
}

////////////////////////////////////////////////////////////////////////


