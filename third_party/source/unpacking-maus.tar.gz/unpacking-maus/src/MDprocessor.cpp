#include "MDprocessManager.h"

uint32_t MDprocessor::GetRunNumber(){
  if (_proMan) return _proMan->GetRunNumber();
  return 0;
}

uint32_t MDprocessor::GetTimeStamp(){
  if (_proMan) return _proMan->GetTimeStamp();
  return 0;
}

string MDprocessor::GetTimeString(){
  if (_proMan) return _proMan->GetTimeString();
  return "";
}

uint32_t MDprocessor::GetLdcId(){
  if (_proMan) return _proMan->GetLdcId();
  return 0;
}

uint32_t MDprocessor::GetEventType(){
  if (_proMan) return _proMan->GetEventType();
  return 0;
}

uint32_t MDprocessor::GetSpillNumber(){
  if (_proMan) return _proMan->GetSpillNumber();
  return 0;
}

uint32_t MDprocessor::GetPhysEventNumber(){
  if (_proMan) return _proMan->GetPhysEventNumber();
  return 0;
}

uint32_t MDprocessor::GetPartEventNumber(){
  if (_proMan) return _proMan->GetPartEventNumber();
  return 0;
}

uint32_t MDprocessor::GetEquipmentType(){
  if (_proMan) return _proMan->GetEquipmentType();
  return 0;
}

uint32_t MDprocessor::GetBoardId(){
  if (_proMan) return _proMan->GetBoardId();
  return 0;
}
